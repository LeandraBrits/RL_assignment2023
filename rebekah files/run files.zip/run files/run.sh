python3 train_lava_NR.py
python3 train_lava_WR.py

python3 train_maze_NR.py
python3 train_maze_WR.py

python3 train_monster_NR.py
python3 train_monster_WR.py

python3 train_quest-hard_NR.py
python3 train_quest-hard_WR.py